import json, random, time, math, requests, os
from datetime import datetime, timezone
from dotenv import load_dotenv

load_dotenv()
BACKEND_URL = os.getenv("BACKEND_URL", "http://localhost:5000/api/sensors/ingest")
INTERVAL_SECONDS = 10

with open("rooms_config.json") as f:
    ROOMS = json.load(f)

runtime_tracker = {r["roomId"]: random.randint(500, 3000) for r in ROOMS}

def hour_of_day():
    return datetime.now().hour

def weather_factor():
    h = hour_of_day()
    return 1.0 + 0.4 * math.sin((h - 6) / 24 * 2 * math.pi)

def occupancy_for(room):
    h = hour_of_day()
    if 9 <= h <= 18:
        return max(0, int(random.gauss(room["baseOccupancy"], 2)))
    return random.randint(0, 1)

def generate_reading(room):
    occ = occupancy_for(room)
    wf = weather_factor()
    base_temp = 22 + 2.5 * wf - 0.15 * occ
    temperature = round(base_temp + random.gauss(0, 0.4), 2)
    humidity = round(45 + 5 * wf + random.gauss(0, 2), 2)

    age_penalty = 1 + (room["ageMonths"] / 100)
    power = round((0.15 * occ + 0.08 * abs(temperature - 22)) * age_penalty + random.uniform(0.1, 0.3), 3)

    runtime_tracker[room["roomId"]] += INTERVAL_SECONDS / 3600
    fault_drift = 0
    if room["ageMonths"] > 36 and random.random() < 0.02:
        fault_drift = random.uniform(2, 6)

    return {
        "roomId": room["roomId"],
        "buildingId": room["buildingId"],
        "floor": room["floor"],
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "temperature": round(temperature + fault_drift, 2),
        "humidity": humidity,
        "occupancy": occ,
        "power": round(power + fault_drift * 0.3, 3),
        "smoke": round(max(0, random.gauss(0.01, 0.005) + (0.05 if fault_drift else 0)), 4),
        "motion": occ > 0,
        "equipment": {
            "id": room["equipmentId"],
            "runtimeHours": round(runtime_tracker[room["roomId"]], 1),
            "ageMonths": room["ageMonths"]
        }
    }

def run():
    print(f"Simulator starting. Posting to {BACKEND_URL} every {INTERVAL_SECONDS}s")
    while True:
        for room in ROOMS:
            reading = generate_reading(room)
            try:
                r = requests.post(BACKEND_URL, json=reading, timeout=5)
                print(f"[{reading['roomId']}] sent -> {r.status_code}")
            except requests.exceptions.RequestException as e:
                print(f"[ERROR] could not reach backend: {e}")
        time.sleep(INTERVAL_SECONDS)

if __name__ == "__main__":
    run()
