// Lays rooms out in a grid, 4 per row, 3 units apart.
export function gridPosition(index, spacing = 3, perRow = 4) {
  return [(index % perRow) * spacing, Math.floor(index / perRow) * spacing, 0];
}
