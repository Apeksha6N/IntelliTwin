import { Canvas } from "@react-three/fiber";
import { OrbitControls } from "@react-three/drei";
import RoomMesh from "./RoomMesh";
import { gridPosition } from "./sceneUtils";

export default function BuildingScene({ rooms, predictions, onSelectRoom }) {
  const predictionFor = (roomId) => predictions.find((p) => p.roomId === roomId);

  return (
    <Canvas camera={{ position: [10, 10, 10], fov: 50 }} style={{ height: "600px" }}>
      <ambientLight intensity={0.6} />
      <directionalLight position={[5, 10, 5]} intensity={0.8} />
      <OrbitControls />
      {rooms.map((room, i) => (
        <RoomMesh
          key={room.roomId}
          position={gridPosition(i)}
          room={room}
          prediction={predictionFor(room.roomId)}
          onSelect={onSelectRoom}
        />
      ))}
    </Canvas>
  );
}
