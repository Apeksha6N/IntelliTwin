import { useState } from "react";
import { Text } from "@react-three/drei";

const riskColorMap = { High: "#ef4444", Medium: "#f59e0b", Low: "#22c55e" };

export default function RoomMesh({ position, room, prediction, onSelect }) {
  const [hovered, setHovered] = useState(false);
  const color = riskColorMap[prediction?.riskLevel] || "#94a3b8";

  return (
    <group position={position}>
      <mesh
        onPointerOver={() => setHovered(true)}
        onPointerOut={() => setHovered(false)}
        onClick={() => onSelect && onSelect(room)}
        scale={hovered ? 1.1 : 1}
      >
        <boxGeometry args={[2, 2, 2]} />
        <meshStandardMaterial color={color} opacity={0.85} transparent />
      </mesh>
      <Text position={[0, 1.4, 0]} fontSize={0.3} color="black">
        {room.roomId}
      </Text>
    </group>
  );
}
