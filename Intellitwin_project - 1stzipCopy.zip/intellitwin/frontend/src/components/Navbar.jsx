import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";

export default function Navbar() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate("/login");
  };

  return (
    <nav className="flex items-center justify-between bg-slate-900 text-white px-6 py-3">
      <div className="font-bold text-lg">IntelliTwin</div>
      <div className="flex gap-4 items-center text-sm">
        <Link to="/">Dashboard</Link>
        <Link to="/twin">3D Twin</Link>
        <Link to="/whatif">What-If</Link>
        <Link to="/reports">Reports</Link>
        {user && (
          <>
            <span className="text-slate-400">{user.name} ({user.role})</span>
            <button onClick={handleLogout} className="bg-red-600 px-3 py-1 rounded">
              Logout
            </button>
          </>
        )}
      </div>
    </nav>
  );
}
