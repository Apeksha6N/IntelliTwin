export default function AlertList({ alerts }) {
  const severityColor = {
    High: "text-red-600",
    Medium: "text-yellow-600",
    Low: "text-green-600",
  };

  if (!alerts.length) {
    return <p className="text-sm text-slate-500">No alerts. Systems nominal.</p>;
  }

  return (
    <ul className="divide-y divide-slate-200">
      {alerts.map((a) => (
        <li key={a._id} className="py-2 text-sm flex justify-between">
          <span>
            <span className={`font-semibold ${severityColor[a.severity]}`}>{a.severity}</span>
            {" — "}{a.roomId}: {a.message}
          </span>
          <span className="text-slate-400">{new Date(a.timestamp).toLocaleTimeString()}</span>
        </li>
      ))}
    </ul>
  );
}
