export default function RoomCard({ room, prediction }) {
  const riskColor = {
    High: "bg-red-100 text-red-700 border-red-300",
    Medium: "bg-yellow-100 text-yellow-700 border-yellow-300",
    Low: "bg-green-100 text-green-700 border-green-300",
  }[prediction?.riskLevel || "Low"];

  return (
    <div className={`rounded-xl border p-4 shadow-sm ${riskColor}`}>
      <h3 className="font-semibold">{room.roomId}</h3>
      <p className="text-sm">Temp: {room.temperature}°C | Power: {room.power} kW</p>
      <p className="text-sm">Risk: {prediction?.riskLevel ?? "—"}</p>
      {prediction?.recommendation && <p className="text-xs mt-1 italic">{prediction.recommendation}</p>}
    </div>
  );
}
