import { Line } from "react-chartjs-2";
import {
  Chart as ChartJS, CategoryScale, LinearScale, PointElement, LineElement, Tooltip, Legend,
} from "chart.js";

ChartJS.register(CategoryScale, LinearScale, PointElement, LineElement, Tooltip, Legend);

export default function SensorChart({ readings, field, label, color = "#3b82f6" }) {
  const data = {
    labels: readings.map(r => new Date(r.timestamp).toLocaleTimeString()),
    datasets: [{
      label,
      data: readings.map(r => r[field]),
      borderColor: color,
      tension: 0.3,
    }],
  };
  return <Line data={data} options={{ responsive: true, animation: false }} />;
}
