import { useEffect, useState } from "react";
import axiosClient from "../api/axiosClient";
import BuildingScene from "../three/BuildingScene";
import SensorChart from "../components/SensorChart";

export default function DigitalTwinView() {
  const [rooms, setRooms] = useState([]);
  const [predictions, setPredictions] = useState([]);
  const [selectedRoom, setSelectedRoom] = useState(null);
  const [history, setHistory] = useState([]);

  useEffect(() => {
    const fetchData = async () => {
      const [roomsRes, predRes] = await Promise.all([
        axiosClient.get("/sensors/latest"),
        axiosClient.get("/predictions/latest"),
      ]);
      setRooms(roomsRes.data);
      setPredictions(predRes.data);
    };
    fetchData();
    const interval = setInterval(fetchData, 10000);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    if (!selectedRoom) return;
    axiosClient.get(`/sensors/room/${selectedRoom.roomId}`).then((res) => setHistory(res.data.reverse()));
  }, [selectedRoom]);

  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold mb-4">3D Digital Twin</h1>
      <p className="text-sm text-slate-500 mb-2">
        Click a room to see its live temperature history. Colour = risk level.
      </p>
      <div className="bg-white rounded-xl border">
        <BuildingScene rooms={rooms} predictions={predictions} onSelectRoom={setSelectedRoom} />
      </div>
      {selectedRoom && (
        <div className="mt-6 bg-white rounded-xl border p-4">
          <h2 className="font-semibold mb-2">{selectedRoom.roomId} — Temperature History</h2>
          {history.length > 0 ? (
            <SensorChart readings={history} field="temperature" label="Temperature (°C)" />
          ) : (
            <p className="text-sm text-slate-500">No history yet.</p>
          )}
        </div>
      )}
    </div>
  );
}
