import { useEffect, useState } from "react";
import axiosClient from "../api/axiosClient";
import RoomCard from "../components/RoomCard";
import AlertList from "../components/AlertList";

export default function AdminDashboard() {
  const [rooms, setRooms] = useState([]);
  const [predictions, setPredictions] = useState([]);
  const [alerts, setAlerts] = useState([]);

  const fetchData = async () => {
    const [roomsRes, predRes, alertsRes] = await Promise.all([
      axiosClient.get("/sensors/latest"),
      axiosClient.get("/predictions/latest"),
      axiosClient.get("/alerts"),
    ]);
    setRooms(roomsRes.data);
    setPredictions(predRes.data);
    setAlerts(alertsRes.data);
  };

  useEffect(() => {
    fetchData();
    const interval = setInterval(fetchData, 10000);
    return () => clearInterval(interval);
  }, []);

  const predictionFor = (roomId) => predictions.find((p) => p.roomId === roomId);

  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold mb-4">Admin Dashboard</h1>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
        {rooms.map((room) => (
          <RoomCard key={room.roomId} room={room} prediction={predictionFor(room.roomId)} />
        ))}
      </div>
      <h2 className="text-xl font-semibold mb-2">Recent Alerts</h2>
      <div className="bg-white rounded-xl border p-4">
        <AlertList alerts={alerts} />
      </div>
    </div>
  );
}
