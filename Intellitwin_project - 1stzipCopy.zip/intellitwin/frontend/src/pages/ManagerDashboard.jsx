import { useEffect, useState } from "react";
import axiosClient from "../api/axiosClient";
import RoomCard from "../components/RoomCard";

export default function ManagerDashboard() {
  const [rooms, setRooms] = useState([]);
  const [predictions, setPredictions] = useState([]);

  useEffect(() => {
    const fetchData = async () => {
      const [roomsRes, predRes] = await Promise.all([
        axiosClient.get("/sensors/latest"),
        axiosClient.get("/predictions/latest"),
      ]);
      setRooms(roomsRes.data);
      setPredictions(predRes.data);
    };
    fetchData();
    const interval = setInterval(fetchData, 10000);
    return () => clearInterval(interval);
  }, []);

  const predictionFor = (roomId) => predictions.find((p) => p.roomId === roomId);
  const totalForecast = predictions.reduce((sum, p) => sum + (p.forecastedEnergyKwh || 0), 0);

  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold mb-4">Manager Dashboard</h1>
      <div className="bg-white rounded-xl border p-4 mb-6 inline-block">
        <p className="text-sm text-slate-500">Total forecasted energy (all rooms)</p>
        <p className="text-3xl font-bold">{totalForecast.toFixed(2)} kWh</p>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {rooms.map((room) => (
          <RoomCard key={room.roomId} room={room} prediction={predictionFor(room.roomId)} />
        ))}
      </div>
    </div>
  );
}
