import { useState } from "react";
import axiosClient from "../api/axiosClient";

export default function WhatIfSimulator() {
  const [form, setForm] = useState({
    temperature: 24,
    humidity: 50,
    occupancy: 8,
    power: 2.5,
    smoke: 0.01,
    runtimeHours: 1500,
    ageMonths: 12,
  });
  const [result, setResult] = useState(null);

  const handleChange = (key) => (e) =>
    setForm((f) => ({ ...f, [key]: parseFloat(e.target.value) }));

  const handleSubmit = async (e) => {
    e.preventDefault();
    const payload = {
      temperature: form.temperature,
      humidity: form.humidity,
      occupancy: form.occupancy,
      power: form.power,
      smoke: form.smoke,
      equipment: { runtimeHours: form.runtimeHours, ageMonths: form.ageMonths },
    };
    const { data } = await axiosClient.post("/whatif", payload);
    setResult(data);
  };

  const fields = [
    { key: "temperature", label: "Temperature (°C)", min: 10, max: 45, step: 0.5 },
    { key: "humidity", label: "Humidity (%)", min: 10, max: 90, step: 1 },
    { key: "occupancy", label: "Occupancy (people)", min: 0, max: 30, step: 1 },
    { key: "power", label: "Power (kW)", min: 0, max: 10, step: 0.1 },
    { key: "smoke", label: "Smoke level", min: 0, max: 1, step: 0.01 },
    { key: "runtimeHours", label: "Equipment Runtime (hrs)", min: 0, max: 8000, step: 50 },
    { key: "ageMonths", label: "Equipment Age (months)", min: 0, max: 120, step: 1 },
  ];

  return (
    <div className="p-6 max-w-2xl">
      <h1 className="text-2xl font-bold mb-4">What-If Scenario Simulator</h1>
      <p className="text-sm text-slate-500 mb-4">
        Tune hypothetical conditions and see what the AI would predict — nothing here is saved to the database.
      </p>
      <form onSubmit={handleSubmit} className="bg-white rounded-xl border p-4 space-y-4">
        {fields.map((f) => (
          <div key={f.key}>
            <label className="text-sm font-medium flex justify-between">
              <span>{f.label}</span>
              <span>{form[f.key]}</span>
            </label>
            <input
              type="range"
              min={f.min}
              max={f.max}
              step={f.step}
              value={form[f.key]}
              onChange={handleChange(f.key)}
              className="w-full"
            />
          </div>
        ))}
        <button type="submit" className="bg-slate-900 text-white rounded px-4 py-2">
          Run Prediction
        </button>
      </form>

      {result && (
        <div className="mt-6 bg-white rounded-xl border p-4">
          <h2 className="font-semibold mb-2">Predicted Outcome</h2>
          <p>Failure Probability: <strong>{result.failureProbability}</strong></p>
          <p>Risk Level: <strong>{result.riskLevel}</strong></p>
          <p>Forecasted Energy: <strong>{result.forecastedEnergyKwh} kWh</strong></p>
          <p>Anomaly Detected: <strong>{result.isAnomaly ? "Yes" : "No"}</strong></p>
          <p className="italic mt-2 text-sm">{result.recommendation}</p>
        </div>
      )}
    </div>
  );
}
