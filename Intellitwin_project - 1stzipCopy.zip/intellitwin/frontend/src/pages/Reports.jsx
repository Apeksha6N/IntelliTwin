import { useState } from "react";
import axiosClient from "../api/axiosClient";

export default function Reports() {
  const [buildingId, setBuildingId] = useState("B1");
  const [from, setFrom] = useState("");
  const [to, setTo] = useState("");
  const [loading, setLoading] = useState(false);

  const downloadReport = async () => {
    setLoading(true);
    try {
      const params = {};
      if (from) params.from = from;
      if (to) params.to = to;
      const res = await axiosClient.get(`/reports/${buildingId}`, {
        params,
        responseType: "blob",
      });
      const url = window.URL.createObjectURL(new Blob([res.data]));
      const link = document.createElement("a");
      link.href = url;
      link.setAttribute("download", `report-${buildingId}.pdf`);
      document.body.appendChild(link);
      link.click();
      link.remove();
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="p-6 max-w-md">
      <h1 className="text-2xl font-bold mb-4">Generate PDF Report</h1>
      <div className="bg-white rounded-xl border p-4 space-y-3">
        <div>
          <label className="text-sm font-medium">Building ID</label>
          <input
            className="w-full border rounded px-3 py-2"
            value={buildingId}
            onChange={(e) => setBuildingId(e.target.value)}
          />
        </div>
        <div>
          <label className="text-sm font-medium">From</label>
          <input type="date" className="w-full border rounded px-3 py-2" value={from} onChange={(e) => setFrom(e.target.value)} />
        </div>
        <div>
          <label className="text-sm font-medium">To</label>
          <input type="date" className="w-full border rounded px-3 py-2" value={to} onChange={(e) => setTo(e.target.value)} />
        </div>
        <button
          onClick={downloadReport}
          disabled={loading}
          className="bg-slate-900 text-white rounded px-4 py-2 w-full"
        >
          {loading ? "Generating..." : "Download PDF"}
        </button>
      </div>
    </div>
  );
}
