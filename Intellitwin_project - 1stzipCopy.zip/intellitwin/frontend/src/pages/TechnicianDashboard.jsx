import { useEffect, useState } from "react";
import axiosClient from "../api/axiosClient";
import AlertList from "../components/AlertList";

export default function TechnicianDashboard() {
  const [alerts, setAlerts] = useState([]);

  const fetchAlerts = async () => {
    const { data } = await axiosClient.get("/alerts");
    setAlerts(data);
  };

  useEffect(() => {
    fetchAlerts();
    const interval = setInterval(fetchAlerts, 10000);
    return () => clearInterval(interval);
  }, []);

  const acknowledge = async (id) => {
    await axiosClient.patch(`/alerts/${id}/acknowledge`);
    fetchAlerts();
  };

  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold mb-4">Technician — Maintenance Queue</h1>
      <div className="bg-white rounded-xl border p-4">
        <AlertList alerts={alerts.filter((a) => !a.acknowledged)} />
      </div>
      <div className="mt-4 space-y-2">
        {alerts.filter((a) => !a.acknowledged).map((a) => (
          <button
            key={a._id}
            onClick={() => acknowledge(a._id)}
            className="block text-xs bg-slate-900 text-white px-3 py-1 rounded"
          >
            Mark "{a.roomId}" resolved
          </button>
        ))}
      </div>
    </div>
  );
}
