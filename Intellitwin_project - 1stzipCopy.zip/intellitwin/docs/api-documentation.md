# IntelliTwin API Documentation

## Auth
- POST /api/auth/register  { name, email, password, role } -> { token, user }
- POST /api/auth/login     { email, password } -> { token, user }
- GET  /api/auth/me        (auth) -> user

## Sensors
- POST /api/sensors/ingest        (called by simulator) -> reading
- GET  /api/sensors/latest        -> latest reading per room
- GET  /api/sensors/room/:roomId  -> last 50 readings for a room

## Predictions
- GET /api/predictions/latest   -> latest prediction per room
- GET /api/predictions/:roomId  -> last 20 predictions for a room

## Rooms
- GET  /api/rooms
- POST /api/rooms  { roomId, buildingId, floor, baseOccupancy, equipmentId, ageMonths }

## Alerts
- GET   /api/alerts
- PATCH /api/alerts/:id/acknowledge

## What-If
- POST /api/whatif  (same shape as a sensor reading) -> prediction (not saved to DB)

## Reports
- GET /api/reports/:buildingId?from=YYYY-MM-DD&to=YYYY-MM-DD -> PDF download

## AI Engine (Python, port 8000)
- POST /predict  (sensor reading shape) -> { failureProbability, forecastedEnergyKwh, isAnomaly, anomalyScore, riskLevel, recommendation }
- GET  /health   -> { status: "ok" }
