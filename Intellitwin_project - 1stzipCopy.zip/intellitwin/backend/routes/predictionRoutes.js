const express = require("express");
const router = express.Router();
const ctrl = require("../controllers/predictionController");

router.get("/latest", ctrl.getAllLatest);
router.get("/:roomId", ctrl.getByRoom);

module.exports = router;
