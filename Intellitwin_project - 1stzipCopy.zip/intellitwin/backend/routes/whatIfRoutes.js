const express = require("express");
const router = express.Router();
const axios = require("axios");

// Forwards a hypothetical reading straight to the AI engine.
// Nothing is written to MongoDB here — that's the point of "what-if".
router.post("/", async (req, res) => {
  try {
    const { data } = await axios.post(`${process.env.AI_ENGINE_URL}/predict`, req.body);
    res.json(data);
  } catch (err) {
    res.status(502).json({ message: "AI engine unreachable", detail: err.message });
  }
});

module.exports = router;
