const express = require("express");
const router = express.Router();
const ctrl = require("../controllers/alertController");

router.get("/", ctrl.list);
router.patch("/:id/acknowledge", ctrl.acknowledge);

module.exports = router;
