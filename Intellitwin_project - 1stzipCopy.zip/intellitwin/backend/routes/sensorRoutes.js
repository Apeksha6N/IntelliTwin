const express = require("express");
const router = express.Router();
const ctrl = require("../controllers/sensorController");

router.post("/ingest", ctrl.ingest);          // called by the simulator (no auth, internal traffic)
router.get("/room/:roomId", ctrl.getLatestByRoom);
router.get("/latest", ctrl.getAllLatest);

module.exports = router;
