const express = require("express");
const router = express.Router();
const ctrl = require("../controllers/reportController");

router.get("/:buildingId", ctrl.generateReport);

module.exports = router;
