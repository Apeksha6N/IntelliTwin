const mongoose = require("mongoose");

const AlertSchema = new mongoose.Schema({
  roomId: { type: String, index: true },
  timestamp: { type: Date, default: Date.now },
  severity: { type: String, enum: ["Low", "Medium", "High"], default: "Medium" },
  message: String,
  acknowledged: { type: Boolean, default: false }
});

module.exports = mongoose.model("Alert", AlertSchema);
