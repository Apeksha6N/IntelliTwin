const mongoose = require("mongoose");

const PredictionSchema = new mongoose.Schema({
  roomId: { type: String, index: true },
  timestamp: { type: Date, default: Date.now },
  failureProbability: Number,
  forecastedEnergyKwh: Number,
  isAnomaly: Boolean,
  anomalyScore: Number,
  riskLevel: { type: String, enum: ["Low", "Medium", "High"], default: "Low" },
  recommendation: String
});

module.exports = mongoose.model("Prediction", PredictionSchema);
