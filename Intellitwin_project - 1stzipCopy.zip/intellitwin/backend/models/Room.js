const mongoose = require("mongoose");

const RoomSchema = new mongoose.Schema({
  roomId: { type: String, required: true, unique: true },
  buildingId: String,
  floor: Number,
  baseOccupancy: Number,
  equipmentId: String,
  ageMonths: Number
});

module.exports = mongoose.model("Room", RoomSchema);
