const mongoose = require("mongoose");

const SensorReadingSchema = new mongoose.Schema({
  roomId: { type: String, required: true, index: true },
  buildingId: String,
  floor: Number,
  timestamp: { type: Date, default: Date.now, index: true },
  temperature: Number,
  humidity: Number,
  occupancy: Number,
  power: Number,
  smoke: Number,
  motion: Boolean,
  equipment: {
    id: String,
    runtimeHours: Number,
    ageMonths: Number
  }
});

module.exports = mongoose.model("SensorReading", SensorReadingSchema);
