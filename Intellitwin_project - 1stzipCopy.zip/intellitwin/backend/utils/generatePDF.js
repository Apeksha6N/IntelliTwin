const PDFDocument = require("pdfkit");

function generatePDF({ buildingId, predictions, alerts }, res) {
  const doc = new PDFDocument({ margin: 40 });
  doc.pipe(res);

  doc.fontSize(20).text("IntelliTwin — Building Report", { align: "center" });
  doc.moveDown();
  doc.fontSize(12).text(`Building: ${buildingId}`);
  doc.text(`Generated: ${new Date().toLocaleString()}`);
  doc.moveDown();

  doc.fontSize(16).text("Predictions", { underline: true });
  doc.moveDown(0.5);
  predictions.forEach((p) => {
    doc.fontSize(10).text(
      `${p.roomId} | ${new Date(p.timestamp).toLocaleString()} | Risk: ${p.riskLevel} | ` +
      `Failure Prob: ${p.failureProbability} | Energy Forecast: ${p.forecastedEnergyKwh} kWh | ` +
      `Anomaly: ${p.isAnomaly}`
    );
  });

  doc.moveDown();
  doc.fontSize(16).text("Alerts", { underline: true });
  doc.moveDown(0.5);
  alerts.forEach((a) => {
    doc.fontSize(10).text(
      `${a.roomId} | ${new Date(a.timestamp).toLocaleString()} | Severity: ${a.severity} | ${a.message}`
    );
  });

  doc.end();
}

module.exports = generatePDF;
