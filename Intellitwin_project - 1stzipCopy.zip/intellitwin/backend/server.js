require("dotenv").config();
const express = require("express");
const cors = require("cors");
const cron = require("node-cron");
const connectDB = require("./config/db");
const axios = require("axios");

const SensorReading = require("./models/SensorReading");
const Prediction = require("./models/Prediction");
const { createFromPrediction } = require("./controllers/alertController");

const authRoutes = require("./routes/authRoutes");
const sensorRoutes = require("./routes/sensorRoutes");
const predictionRoutes = require("./routes/predictionRoutes");
const roomRoutes = require("./routes/roomRoutes");
const alertRoutes = require("./routes/alertRoutes");
const whatIfRoutes = require("./routes/whatIfRoutes");
const reportRoutes = require("./routes/reportRoutes");

const app = express();
app.use(cors());
app.use(express.json());

connectDB();

app.use("/api/auth", authRoutes);
app.use("/api/sensors", sensorRoutes);
app.use("/api/predictions", predictionRoutes);
app.use("/api/rooms", roomRoutes);
app.use("/api/alerts", alertRoutes);
app.use("/api/whatif", whatIfRoutes);
app.use("/api/reports", reportRoutes);

app.get("/", (req, res) => res.json({ status: "IntelliTwin backend running" }));

// Every 60s: pull latest readings, ask the AI engine for predictions, store them + raise alerts
cron.schedule("*/60 * * * * *", async () => {
  try {
    const latest = await SensorReading.aggregate([
      { $sort: { timestamp: -1 } },
      { $group: { _id: "$roomId", latest: { $first: "$$ROOT" } } }
    ]);
    for (const { latest: reading } of latest) {
      const { data } = await axios.post(`${process.env.AI_ENGINE_URL}/predict`, reading);
      const prediction = await Prediction.create({ roomId: reading.roomId, ...data });
      await createFromPrediction(prediction);
    }
  } catch (err) {
    console.error("Prediction cron failed:", err.message);
  }
});

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`Backend running on port ${PORT}`));
