const Prediction = require("../models/Prediction");

exports.getByRoom = async (req, res) => {
  const { roomId } = req.params;
  const predictions = await Prediction.find({ roomId }).sort({ timestamp: -1 }).limit(20);
  res.json(predictions);
};

exports.getAllLatest = async (req, res) => {
  const results = await Prediction.aggregate([
    { $sort: { timestamp: -1 } },
    { $group: { _id: "$roomId", latest: { $first: "$$ROOT" } } }
  ]);
  res.json(results.map((r) => r.latest));
};
