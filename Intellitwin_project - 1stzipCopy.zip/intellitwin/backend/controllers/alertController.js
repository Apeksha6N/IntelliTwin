const Alert = require("../models/Alert");
const Prediction = require("../models/Prediction");

exports.list = async (req, res) => {
  const alerts = await Alert.find().sort({ timestamp: -1 }).limit(100);
  res.json(alerts);
};

exports.acknowledge = async (req, res) => {
  const alert = await Alert.findByIdAndUpdate(req.params.id, { acknowledged: true }, { new: true });
  res.json(alert);
};

// Called internally by the cron job when a prediction crosses the High risk threshold
exports.createFromPrediction = async (prediction) => {
  if (prediction.riskLevel === "High" || prediction.isAnomaly) {
    await Alert.create({
      roomId: prediction.roomId,
      severity: prediction.riskLevel,
      message: prediction.recommendation
    });
  }
};
