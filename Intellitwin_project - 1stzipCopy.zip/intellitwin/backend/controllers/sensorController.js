const SensorReading = require("../models/SensorReading");

exports.ingest = async (req, res) => {
  try {
    const reading = await SensorReading.create(req.body);
    res.status(201).json(reading);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
};

exports.getLatestByRoom = async (req, res) => {
  const { roomId } = req.params;
  const readings = await SensorReading.find({ roomId }).sort({ timestamp: -1 }).limit(50);
  res.json(readings);
};

exports.getAllLatest = async (req, res) => {
  const results = await SensorReading.aggregate([
    { $sort: { timestamp: -1 } },
    { $group: { _id: "$roomId", latest: { $first: "$$ROOT" } } }
  ]);
  res.json(results.map((r) => r.latest));
};
