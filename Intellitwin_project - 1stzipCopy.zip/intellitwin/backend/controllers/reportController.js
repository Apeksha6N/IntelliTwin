const Prediction = require("../models/Prediction");
const Alert = require("../models/Alert");
const generatePDF = require("../utils/generatePDF");

exports.generateReport = async (req, res) => {
  const { buildingId } = req.params;
  const { from, to } = req.query;

  const dateFilter = {};
  if (from) dateFilter.$gte = new Date(from);
  if (to) dateFilter.$lte = new Date(to);

  const predictions = await Prediction.find(
    Object.keys(dateFilter).length ? { timestamp: dateFilter } : {}
  ).sort({ timestamp: -1 }).limit(200);

  const alerts = await Alert.find(
    Object.keys(dateFilter).length ? { timestamp: dateFilter } : {}
  ).sort({ timestamp: -1 }).limit(200);

  res.setHeader("Content-Type", "application/pdf");
  res.setHeader("Content-Disposition", `attachment; filename=report-${buildingId}.pdf`);

  generatePDF({ buildingId, predictions, alerts }, res);
};
