from flask import Flask, request, jsonify
from flask_cors import CORS
import joblib
import pandas as pd
from datetime import datetime
from services.recommendation_engine import generate_recommendation, risk_level

app = Flask(__name__)
CORS(app)

maintenance_model = joblib.load("models/saved/maintenance_rf.joblib")
anomaly_model = joblib.load("models/saved/anomaly_iforest.joblib")
energy_model = joblib.load("models/saved/energy_forecast.joblib")

@app.route("/predict", methods=["POST"])
def predict():
    data = request.get_json()

    maint_features = pd.DataFrame([{
        "temperature": data["temperature"],
        "power": data["power"],
        "runtimeHours": data["equipment"]["runtimeHours"],
        "ageMonths": data["equipment"]["ageMonths"],
    }])
    failure_prob = float(maintenance_model.predict_proba(maint_features)[0][1])

    anomaly_features = pd.DataFrame([{
        "temperature": data["temperature"],
        "humidity": data["humidity"],
        "power": data["power"],
        "smoke": data["smoke"],
    }])
    anomaly_pred = anomaly_model.predict(anomaly_features)[0]
    anomaly_score = float(anomaly_model.decision_function(anomaly_features)[0])
    is_anomaly = bool(anomaly_pred == -1)

    energy_features = pd.DataFrame([{
        "occupancy": data["occupancy"],
        "temperature": data["temperature"],
        "hourOfDay": datetime.now().hour,
    }])
    forecast_kwh = float(energy_model.predict(energy_features)[0])

    return jsonify({
        "failureProbability": round(failure_prob, 3),
        "forecastedEnergyKwh": round(forecast_kwh, 3),
        "isAnomaly": is_anomaly,
        "anomalyScore": round(anomaly_score, 3),
        "riskLevel": risk_level(failure_prob),
        "recommendation": generate_recommendation(failure_prob, is_anomaly, forecast_kwh)
    })

@app.route("/health", methods=["GET"])
def health():
    return jsonify({"status": "ok"})

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8000, debug=True)
