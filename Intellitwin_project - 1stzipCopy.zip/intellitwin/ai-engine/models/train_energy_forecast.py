import numpy as np
import pandas as pd
from sklearn.linear_model import Ridge
import joblib

np.random.seed(7)
N = 5000
df = pd.DataFrame({
    "occupancy": np.random.randint(0, 20, N),
    "temperature": np.random.normal(26, 4, N),
    "hourOfDay": np.random.randint(0, 24, N),
})
df["power"] = (
    0.15 * df["occupancy"] +
    0.08 * (df["temperature"] - 22).clip(lower=0) +
    0.02 * np.sin(df["hourOfDay"] / 24 * 2 * np.pi) +
    np.random.normal(0, 0.2, N)
).clip(lower=0)

X = df[["occupancy", "temperature", "hourOfDay"]]
y = df["power"]
model = Ridge(alpha=1.0)
model.fit(X, y)
joblib.dump(model, "saved/energy_forecast.joblib")
print("Saved model to saved/energy_forecast.joblib")
