import numpy as np
import pandas as pd
from sklearn.ensemble import IsolationForest
import joblib

np.random.seed(1)
N = 5000
df = pd.DataFrame({
    "temperature": np.random.normal(24, 1.5, N),
    "humidity": np.random.normal(50, 5, N),
    "power": np.random.normal(2.2, 0.7, N).clip(0),
    "smoke": np.random.normal(0.01, 0.005, N).clip(0),
})

model = IsolationForest(n_estimators=200, contamination=0.03, random_state=1)
model.fit(df)
joblib.dump(model, "saved/anomaly_iforest.joblib")
print("Saved model to saved/anomaly_iforest.joblib")
