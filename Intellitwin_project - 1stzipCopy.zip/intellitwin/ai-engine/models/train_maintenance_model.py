"""
Trains a Random Forest classifier to estimate failure probability.
Uses a synthetic labeled dataset tying failure risk to temperature,
power, runtime hours, and equipment age. Standard for a prototype
without real historical failure data yet.
"""
import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report
import joblib

np.random.seed(42)
N = 5000

df = pd.DataFrame({
    "temperature": np.random.normal(26, 4, N),
    "power": np.random.normal(2.5, 1.2, N).clip(0),
    "runtimeHours": np.random.uniform(100, 5000, N),
    "ageMonths": np.random.uniform(1, 60, N),
})

risk_score = (
    0.015 * df["ageMonths"] +
    0.0006 * df["runtimeHours"] +
    0.08 * (df["temperature"] - 26).abs() +
    0.2 * (df["power"] > 4.5).astype(int) +
    np.random.normal(0, 0.5, N)
)
df["failure"] = (risk_score > risk_score.quantile(0.8)).astype(int)

X = df[["temperature", "power", "runtimeHours", "ageMonths"]]
y = df["failure"]

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
model = RandomForestClassifier(n_estimators=200, max_depth=8, random_state=42)
model.fit(X_train, y_train)

print(classification_report(y_test, model.predict(X_test)))
joblib.dump(model, "saved/maintenance_rf.joblib")
print("Saved model to saved/maintenance_rf.joblib")
