def generate_recommendation(failure_prob, is_anomaly, forecast_kwh):
    if failure_prob > 0.7:
        return "High failure risk: schedule technician inspection within 48 hours."
    if is_anomaly:
        return "Abnormal sensor pattern detected: verify equipment and sensor wiring."
    if forecast_kwh > 4.0:
        return "Elevated energy forecast: consider adjusting HVAC setpoint or occupancy scheduling."
    return "No action needed. Systems operating within normal parameters."

def risk_level(failure_prob):
    if failure_prob > 0.7:
        return "High"
    if failure_prob > 0.4:
        return "Medium"
    return "Low"
