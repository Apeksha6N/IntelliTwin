# IntelliTwin

AI-Powered Digital Twin Platform for Smart Building Monitoring, Predictive Maintenance, and Intelligent Energy Optimization.

## Structure
- `simulator/` — Python virtual IoT sensor simulator
- `backend/` — Node.js + Express + MongoDB REST API
- `ai-engine/` — Python Flask microservice (ML models)
- `frontend/` — React + Tailwind + Chart.js + Three.js dashboard
- `docs/` — diagrams and API docs

## Quick Start
See `docs/SETUP_GUIDE.md` for the full step-by-step walkthrough.

Run order: MongoDB Atlas → backend → ai-engine → simulator → frontend.
